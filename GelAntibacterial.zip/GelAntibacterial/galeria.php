<?php
session_start();
if(isset($_SESSION['usuario']))
{
    $usuarioSesion=$_SESSION['usuario'];
    $tipoSesion=$_SESSION['tipo'];
    $nombreSesion=$_SESSION['nombreUsuario'];    
}
else
{
    $usuarioSesion='';
    $tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Bootstrap/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>    
    <title>GelAntibacteria.com</title>
</head>
<body background="img/fondo2.jpg">
<header>
<table width ="220%" border="0">
        <tr> <!--encabezado-->
            <td colspan="2">
            <img src="img/nosotros.jpg">
            </td>
        </tr>
        </table>
</header>
        <ul>
        <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" href="index.php">INICIO</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="nosotros.php">NOSOTROS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="galeria.php">GALERIA</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactanos.php">CONTACTANOS</a>
  </li>
</ul>
</nav>
                <?php
                    if($tipoSesion==1)
                    {
                        ?> <li>
                            <a href="Inventarios/inventario.php">Inventario</a>
                        </li>
                        <?php
                    }
                ?>
            <li>
            <?php
            if($usuarioSesion<>'')
            {
                ?>
                <p><?php echo $nombreSesion."(". $usuarioSesion.")" ?></p>
                <a href="Usuarios/cerrarsesion.php">Cerrar sesion</a>
                <?php
            }
            else
            {
              ?>
                <a href="Usuarios/cerrarsesion.php">Iniciar sesion</a> 
                <?php
            }
        ?>
            </li>
        </ul>
    </nav>
    <center><h1>"GRAN VARIEDAD DE GEL ANTIBACTERIAL"</h1></center>
    <img src="img/ima1.jpg" width="225px" height="225px">
    <img src="img/ima2.jpg"width="225px" height="225px">
    <img src="img/ima3.jpg"width="225px" height="225px">
    <img src="img/ima4.png"width="225px" height="225px">
    <img src="img/ima5.jpg"width="225px" height="225px">
    <img src="img/ima6.jpg"width="225px" height="225px">
    <img src="img/ima7.jpg"width="225px" height="225px">
    <img src="img/ima8.jpg"width="225px" height="225px">
    <img src="img/ima9.jpg"width="225px" height="225px">
    <img src="img/ima10.jpg"width="225px" height="225px">
    <img src="img/ima11.jpg"width="225px" height="225px">
    <img src="img/ima12.jpg"width="225px" height="225px">
    <img src="img/ima13.jpeg"width="225px" height="225px">
    <img src="img/ima14.jpg"width="225px" height="225px">
    <img src="img/ima15.jpg"width="225px" height="225px">
    <img src="img/ima16.jpg"width="225px" height="225px">
    <center>

<footer>
        <center><p>Boulevar Belisario Dominguez, Kilometro 1081, Sin Numero, Teran Tuxtla Gutierrez, Chiapas.</p>
        <p>&copy; 2020 Drechos reservados</p></center>
    </footer>
</body>
</html>