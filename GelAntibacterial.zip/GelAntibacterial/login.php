<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>GelAntibacterial.com - login</title>
</head>
<body bgcolor='#FF9B61'>
  <div>
  <div class = "form" >
        <h2>iniciar sesion</h2>
        <form action="Usuarios/validarusuario.php" method="post" >
        <p>Correo electronico</p>
        <label for="correo"></label>
        <input type="text" name="correo" placefolder="Escribe tu correo">
        <br>
        <p>Password</p>
        <label for="Pasword"></label>
        <input type="password" name="pass">
        <input type="submit" value="Enviar">
        <br>
        <center> 
       <table border="3"> 
        <tr>
            <td>
            <a href="Usuarios/nuevousuario.php">Crear cuenta</a> 
            </td>           
        </tr>
    </table>
    </center>
        </form>
    </div>
<div>
</div> 
</body>
</html>