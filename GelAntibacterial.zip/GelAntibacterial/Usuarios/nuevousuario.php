<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <title>GelAntibacterial.com - Registro</title>
</head>
<body bgcolor='#69FF8E'>


    <div class = "form" >
        <form action="guardarusuario.php" method="post" >
        <p>Nombre Completo</p>
        <label for="nombrecompleto"></label>
        <input type="text" name="nombrecompleto" placeholder="Escribe tu nombre">
        <br>
        <p>Correo Electronico</p>
        <label for="correo"></label>
        <input type="text" name="correo" placeholder="Escribe tu Correo">
        <br>
        <p>Password</p>
        <input type="password" name="pass">
        <button>
        <input type="submit" value="Guardar">
        <img src="../img/enviar.jpeg" alt="imagen" width="32" height="32" style="vertical-align:middle" >
        
        </button>
        <br>
        </form>
    </div>
</body>
</html>