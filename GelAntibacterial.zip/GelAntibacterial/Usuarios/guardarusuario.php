<?php
 include_once "../conexion.php";
 $nombre=$_POST['nombrecompleto'];
 $correo=$_POST['correo'];
 $pass=$_POST['pass'];
 $conexion=new mysqli($servedorBD,$usuarioBD,$passwordBD,$nombreBD);
 $consulta="INSERT INTO usuarios(NombreCompleto,Correo,Password,Tipo) VALUES('$nombre','$correo','$pass',2)";
    if($resultado=$conexion->query($consulta))
  {
      header("Location:../login.php");
  }
    else {
        header("Location:guardarusuario.php");
    }
?>