<?php
 $servidorBD="localhost";
 $usuarioBD="root";
 $passwordBD="";
 $nombreBD="GelAntibacterial";

?>