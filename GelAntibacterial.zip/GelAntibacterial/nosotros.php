<?php
session_start();
if(isset($_SESSION['usuario']))
{
    $usuarioSesion=$_SESSION['usuario'];
    $tipoSesion=$_SESSION['tipo'];
    $nombreSesion=$_SESSION['nombreUsuario'];    
}
else
{
    $usuarioSesion='';
    $tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Bootstrap/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>    
    <title>GelAntibacteria.com</title>
</head>
<body background="img/fondo2.jpg">
<header>
<table width ="220%" border="0">
        <tr> <!--encabezado-->
            <td colspan="2">
            <img src="img/nosotros.jpg">
            </td>
        </tr>
        </table>
</header>
        <ul>
        <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" href="index.php">INICIO</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="nosotros.php">NOSOTROS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="galeria.php">GALERIA</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactanos.php">CONTACTANOS</a>
  </li>
</ul>
</nav>
                <?php
                    if($tipoSesion==1)
                    {
                        ?> <li>
                            <a href="Inventarios/inventario.php">Inventario</a>
                        </li>
                        <?php
                    }
                ?>
            <li>
            <?php
            if($usuarioSesion<>'')
            {
                ?>
                <p><?php echo $nombreSesion."(". $usuarioSesion.")" ?></p>
                <a href="Usuarios/cerrarsesion.php">Cerrar sesion</a>
                <?php
            }
            else
            {
              ?>
                <a href="Usuarios/cerrarsesion.php">Iniciar sesion</a> 
                <?php
            }
        ?>
            </li>
        </ul>
    </nav>
<p align="justify"> El desarrollo de una tienda en línea la cual se basa en la venta de
gel Antibacterial para el cuidado de la salud de las personas y la
eliminación de bacterias.
La problemática que enfrentaremos es la anti salud en las manos de las personas la cual con frecuencia tenemos
contacto con diferentes productos lo cual contienen diferentes tipos de bacterias las cuales son dañinas para el
cuerpo humano, a lo cual nosotros ponemos a disposición en nuestra tienda en línea la venta de gel Antibacterial
el cual está comprobado científicamente que elimina las bacterias hasta un 90% en nuestra tienda en línea
tenemos gel Antibacterial de diferentes marcas, la cual sea de su agrado de nuestros clientes.
</p>
<footer>
        <center><p>Boulevar Belisario Dominguez, Kilometro 1081, Sin Numero, Teran Tuxtla Gutierrez, Chiapas.</p>
        <p>&copy; 2020 Drechos reservados</p></center>
    </footer>
</body>
</html>