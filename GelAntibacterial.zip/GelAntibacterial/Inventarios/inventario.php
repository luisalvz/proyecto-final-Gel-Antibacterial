<?php
session_start();
if(isset($_SESSION['usuario']))
{
    $usuarioSesion=$_SESSION['usuario'];
    $tipoSesion=$_SESSION['tipo'];
    $nombreSesion=$_SESSION['nombreUsuario'];  
    if($tipoSesion<>1)
    {
        header("Location: ../index.php");
    }  
    if(isset($_GET['idEliminar'])){
        include_once "../conexion.php";
        $conexion=new mysqli($servidorBD,$usuarioBD,$passwordBD,$nombreBD);
        $consulta="DELETE FROM Productos WHERE Id=".$_GET['idEliminar'];
        $resultado=$conexion->query($consulta);
        header("Location: $_SERVER[PHP_SELF]");

    }
}
else
{
    $usuarioSesion='';
    $tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Bootstrap/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>    
    <title>GelAntibacteria.com</title>
    <script type="text/javascript">
            function editar(id){

            }
            function eliminar(id){
                if(confirm('¿Estas seguro de eliminar?'))
                {
                    window.location.href='inventario.php?idEliminar='+id;
                }
            }
    </script>
</head>
<body>
<body bgcolor="#A6E9EB">
<header>
<table width ="220%" border="0">
        <tr> <!--encabezado-->
            <td colspan="2">
            <img src="../img/banner.jpg">
            </td>
        </tr>
        </table>
</header>

<ul>
        <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" href="../index.php">INICIO</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="nosotros.php">NOSOTROS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="galeria.php">GALERIA</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="contactanos.php">CONTACTANOS</a>
  </li>
</ul>
</nav>
            <?php
            if($usuarioSesion<>'')
            {
                ?>
                <p><?php echo $nombreSesion."(". $usuarioSesion.")" ?></p>
                <a href="../Usuarios/cerrarsesion.php">Cerrar sesion</a>
                <?php
            }
            else
            {
              ?>
                <a href="../Usuarios/cerrarsesion.php">Iniciar sesion</a> 
                <?php
            }
        ?>
            </li>
        </ul>
    </nav>
    <h1>Lista de inventarios</h1>
    <a href="nuevoinventario.php">Nuevo</a>
<div>
     <table>
         <thead>
                <tr>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Existencia</th>
                    <th> </th>
                </tr>
        </thead>
        <tbody>
            <?php
                include_once '../conexion.php';
                $conexion=new mysqli($servidorBD,$usuarioBD,$passwordBD,$nombreBD);
                $consulta="SELECT * FROM PRODUCTOS";
                $resultado=$conexion->query($consulta);
                while($registro=$resultado->fetch_assoc())
                {
                    ?>
                    <tr>
                    <td> <?php echo $registro['Id'];?> </td>
                    <td> <?php echo $registro['Nombre'];?> </td>
                    <td> <?php echo $registro['Precio'];?> </td>
                    <td> <?php echo $registro['Existencia'];?> </td>
                    <td> 
                    <a href="javascript:editar('<?php echo $registro['Id']?>')">
                            <img src="../img/Editar.jpg" alt="" srcset="" style='width:60px;height=60px;'>
                    </a>
                        </td>
                    <td>
                     <a href="javascript:eliminar('<?php echo $registro['Id']?>')">
                     <img src="../img/cancelar.png" alt="" srcset="" style='width:60px;height=60px;'>
                     </a>

                     </td>
                    </tr>
                    <?php
                }
            ?>
        </tbody>
    </table>
</div>
</body>
</html>