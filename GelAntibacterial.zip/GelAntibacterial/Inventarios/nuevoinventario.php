<?php
session_start();
if(isset($_SESSION['usuario']))
{
    $usuarioSesion=$_SESSION['usuario'];
    $tipoSesion=$_SESSION['tipo'];
    $nombreSesion=$_SESSION['nombreUsuario'];  
    if($tipoSesion<>1)
    {
        header("Location: ../index.php");
    }  
}
else
{
    $usuarioSesion='';
    $tipoSesion='';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GelAntibacteria.com</title>
</head>
<body>
    <h1>GelAntibacteria.com</h1>
    <nav>
        <ul>
            <li><a href="../index.php">inicio</a></li>
            <li><a href="">Nosotros</a></li>
            <li><a href="">Catalogo</a></li>
            <li><a href="">Contactanos</a></li>
                <?php
                    if($tipoSesion==1)
                    {
                        ?> <li>
                            <a href="inventario.php">Inventario</a>
                        </li>
                        <?php
                    }
                ?>
            <li>
            <?php
            if($usuarioSesion<>'')
            {
                ?>
                <p><?php echo $nombreSesion."(". $usuarioSesion.")" ?></p>
                <a href="Usuarios/cerrarsesion.php">Cerrar sesion</a>
                <?php
            }
            else
            {
              ?>
                <a href="Usuarios/cerrarsesion.php">Iniciar sesion</a> 
                <?php
            }
        ?>
            </li>
        </ul>
    </nav>
    <h1>Datos del Producto</h1>
<div>
    <form action="guardarinventario.php" method="post">
        <labe>nombre:</labe>
        <input type="text" name= "nombre" placeholder="nombre del producto">
        <labe>precio:</labe>
        <input type="text" name= "precio" placeholder="precio">
        <labe>Existencia </labe>
        <input type="text" name="existencia" placeholder="escriba la existencia">
        <input type="submit" value="Guardar">
    </form>
</div>
</body>
</html>