<?php
session_start();
if(isset($_SESSION['usuario']))
{
    $usuarioSesion=$_SESSION['usuario'];
    $tipoSesion=$_SESSION['tipo'];
    $nombreSesion=$_SESSION['nombreUsuario'];  
    $id=$_GET['id'];
    include_once 'conexion.php';
    $conexion=new mysqli($servidorBD,$usuarioBD,$passwordBD,$nombreBD);
    $consulta="SELECT * FROM PRODUCTOS where Id='".$id."'";
    $resultado=$conexion->query($consulta);
    if($registro=$resultado->fetch_array(MYSQLI_ASSOC))
    {
        $nombre=$registro['Nombre'];
        $precio=$registro['Precio'];
        $existencia=$registro['Existencia'];
    }
}
else
{
   header("Location: login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="Bootstrap/bootstrap.min.css">
    <script type="text/javascript" src="js/bootstrap.min.js"></script>    
    <title>GelAntibacteria.com</title>
</head>
<body bgcolor="#D0F4F5">
<header>
<table width ="220%" border="0">
        <tr> <!--encabezado-->
            <td colspan="2">
            <img src="img/ima1.jpg">
            </td>
        </tr>
        </table>
</header>
        <ul>
        <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" href="index.php">INICIO</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">NOSOTROS</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">GALERIA</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">CONTACTANOS</a>
  </li>
</ul>
</nav>
                <?php
                    if($tipoSesion==1)
                    {
                        ?> <li>
                            <a href="Inventarios/inventario.php">Inventario</a>
                        </li>
                        <?php
                    }
                ?>
            <li>
            <?php
            if($usuarioSesion<>'')
            {
                ?>
                <p><?php echo $nombreSesion."(". $usuarioSesion.")" ?></p>
                <a href="Usuarios/cerrarsesion.php">Cerrar sesion</a>
                <?php
            }
            else
            {
              ?>
                <a href="Usuarios/cerrarsesion.php">Iniciar sesion</a> 
                <?php
            }
        ?>
            </li>
        </ul>
    </nav>
<div>
        <form action="guardarCompra.php" method="post">
        <labe>Id:</labe>
        <input type="text" name= "id" placeholder="nombre del producto" value="<?php echo $id ?>" readonly >
        <labe>nombre:</labe>
        <input type="text" name= "nombre" placeholder="nombre del producto" value="<?php echo $nombre ?>" readonly >
        <labe>precio:</labe>
        <input type="text" name= "precio" placeholder="precio" value="<?php echo $precio ?>" readonly >
        <labe>Existencia </labe>
        <input type="text" name="existencia" placeholder="escriba la existencia" value="<?php echo $existencia ?>" readonly >
        <labe>Cantidad a comprar </labe>
        <input type="text" name="cantidad" placeholder="escriba la cantidad" >
        <input type="submit" value="Guardar">
            </form>
</div>>
</body>
</html>